class Post {
  String title;
  String id;
  String details;
  String uid;
  int timestamp;
  double longitude;
  double latitude;

  Post(this.id, this.title, this.details, this.uid, this.timestamp, this.longitude, this.latitude);
}
