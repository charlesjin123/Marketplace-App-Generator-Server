class Contact {
  String username;
  String uid;
  String imageURL;
  String lastMessage;
  bool hasUnread;

  Contact(this.username, this.uid, this.imageURL, this.lastMessage, this.hasUnread);
}
