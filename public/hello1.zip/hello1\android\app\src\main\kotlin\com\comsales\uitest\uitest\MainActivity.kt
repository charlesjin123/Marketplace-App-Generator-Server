package com.comsales.uitest.uitest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
